//$('.message a').click(function () {

//    $('form').animate({ height: "toggle", opacity: "toggle" }, "slow");
//});


$("#LoginBtn").click(function () {
    $('.login-form').show(300);
    $('.forgot-form').hide(300);
    $('.register-form').hide(300);
});

$("#registerBtn").click(function () {
    $('.login-form').hide(300);
    $('.forgot-form').hide(300);
    $('.register-form').show(300);
});

$("#forgotBtn").click(function () {
    $('.login-form').hide(300);
    $('.forgot-form').show();
    $('.register-form').hide(300);
});

$("#LoginforBtn").click(function () {
    $('.login-form').show(300);
    $('.forgot-form').hide(300);
    $('.register-form').hide(300);
});

let digitValidate = function (ele) {
    console.log(ele.value);
    ele.value = ele.value.replace(/[^0-9]/g, '');
}

let tabChange = function (val) {
    let ele = document.querySelectorAll('input');
    if (ele[val - 1].value != '') {
        ele[val].focus()
    } else if (ele[val - 1].value == '') {
        ele[val - 2].focus()
    }
}

$(document).ready(function () {
    $('#searchBtn').click(function () {
        $('#dashboard-grid').show("");
    });

    $('#veryBtn').click(function () {
        $('#otp-section').show("");
    });

});

$(function () {
    $("#datepickerfrom").datepicker({
        dateFormat: "dd-mm-yy"
        , duration: "fast"
    });
});
$(function () {
    $("#datepickerTo").datepicker({
        dateFormat: "dd-mm-yy"
        , duration: "fast"
    });
});
